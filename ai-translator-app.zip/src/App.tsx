import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ThreeTranslatorInterface } from './components/ThreeTranslatorInterface';
import { LiveConversation } from './components/LiveConversation';
import { FeatureGrid } from './components/FeatureGrid';
import { CTASection } from './components/CTASection';
import { HistoryDrawer } from './components/HistoryDrawer';
import { HistoryItem } from './types';
import { Sparkles, Globe } from 'lucide-react';

export default function App() {
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('linguasphere_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [selectedBubbleLang, setSelectedBubbleLang] = useState<string>('');

  useEffect(() => {
    try {
      localStorage.setItem('linguasphere_history', JSON.stringify(history.slice(0, 20)));
    } catch (e) {
      console.error('Failed to save history to localStorage', e);
    }
  }, [history]);

  const handleAddHistory = (item: HistoryItem) => {
    setHistory((prev) => [item, ...prev.filter((i) => i.sourceText !== item.sourceText)]);
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem('linguasphere_history');
  };

  const handleSelectHistoryItem = (item: HistoryItem) => {
    const el = document.getElementById('translator');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white relative overflow-x-hidden">
      
      {/* Background Neon Grid Glow Accents */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[1200px] max-w-full h-[500px] bg-gradient-to-b from-indigo-900/20 via-purple-900/10 to-transparent blur-3xl pointer-events-none -z-10" />
      <div className="fixed bottom-0 right-0 w-[600px] max-w-full h-[600px] bg-cyan-950/20 blur-3xl pointer-events-none -z-10" />
      <div className="fixed top-1/3 left-0 w-[500px] max-w-full h-[500px] bg-purple-950/20 blur-3xl pointer-events-none -z-10" />

      {/* Navigation Header */}
      <Header
        historyCount={history.length}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 flex flex-col items-center space-y-12 sm:space-y-16 pb-12">
        
        {/* 1. Hero Section with Interactive Rotating 3D Globe & Floating Language Bubbles */}
        <HeroSection
          onSelectBubbleLanguage={(code) => setSelectedBubbleLang(code)}
        />

        {/* 2. 3D Translation Interface Section */}
        <div className="w-full max-w-6xl">
          <ThreeTranslatorInterface
            onAddHistory={handleAddHistory}
            selectedTargetFromBubble={selectedBubbleLang}
          />
        </div>

        {/* 3. Live Conversation Section with Dual 3D Avatars */}
        <div className="w-full">
          <LiveConversation />
        </div>

        {/* 4. Six Glassmorphism Feature Cards Section */}
        <div className="w-full">
          <FeatureGrid />
        </div>

        {/* 5. Futuristic CTA Section */}
        <div className="w-full">
          <CTASection />
        </div>

      </main>

      {/* History Slide-out Drawer */}
      <HistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onClearHistory={handleClearHistory}
        onSelectHistoryItem={handleSelectHistoryItem}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/90 py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <Globe className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-slate-300">LinguaSphere AI</span>
            <span>• 3D AI Translation Platform</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-400">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Powered by Gemini 3.6 Flash Engine</span>
          </div>
        </div>
      </footer>

    </div>
  );
}

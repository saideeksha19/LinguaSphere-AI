export interface Language {
  code: string; // e.g., 'en', 'es', 'auto'
  name: string; // e.g., 'English', 'Spanish'
  nativeName?: string;
  speechCode?: string; // e.g., 'en-US'
  flag?: string;
}

export type FormalityStyle = 'default' | 'formal' | 'casual';

export interface TranslationRequest {
  text: string;
  sourceLang: string;
  targetLang: string;
  formality?: FormalityStyle;
}

export interface TranslationResponse {
  translatedText: string;
  detectedLanguage?: string;
  pronunciation?: string;
  contextNote?: string;
  error?: string;
}

export interface HistoryItem {
  id: string;
  sourceText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  detectedLanguage?: string;
  pronunciation?: string;
  contextNote?: string;
  timestamp: number;
}

import { Language } from '../types';

export const SOURCE_LANGUAGES: Language[] = [
  { code: 'auto', name: 'Auto Detect', flag: '🌐' },
  { code: 'en', name: 'English', nativeName: 'English', speechCode: 'en-US', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', speechCode: 'es-ES', flag: '🇪🇸' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', speechCode: 'hi-IN', flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', speechCode: 'kn-IN', flag: '🇮🇳' },
  { code: 'fr', name: 'French', nativeName: 'Français', speechCode: 'fr-FR', flag: '🇫🇷' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', speechCode: 'ja-JP', flag: '🇯🇵' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', speechCode: 'de-DE', flag: '🇩🇪' },
  { code: 'zh-CN', name: 'Chinese (Simplified)', nativeName: '简体中文', speechCode: 'zh-CN', flag: '🇨🇳' },
  { code: 'zh-TW', name: 'Chinese (Traditional)', nativeName: '繁體中文', speechCode: 'zh-TW', flag: '🇭🇰' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', speechCode: 'ko-KR', flag: '🇰🇷' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', speechCode: 'te-IN', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', speechCode: 'ta-IN', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', speechCode: 'mr-IN', flag: '🇮🇳' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', speechCode: 'ar-SA', flag: '🇸🇦' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', speechCode: 'pt-PT', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', speechCode: 'ru-RU', flag: '🇷🇺' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', speechCode: 'it-IT', flag: '🇮🇹' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', speechCode: 'nl-NL', flag: '🇳🇱' },
  { code: 'pl', name: 'Polish', nativeName: 'Polski', speechCode: 'pl-PL', flag: '🇵🇱' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', speechCode: 'tr-TR', flag: '🇹🇷' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', speechCode: 'vi-VN', flag: '🇻🇳' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย', speechCode: 'th-TH', flag: '🇹🇭' },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia', speechCode: 'id-ID', flag: '🇮🇩' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska', speechCode: 'sv-SE', flag: '🇸🇪' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά', speechCode: 'el-GR', flag: '🇬🇷' },
  { code: 'cs', name: 'Czech', nativeName: 'Čeština', speechCode: 'cs-CZ', flag: '🇨🇿' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית', speechCode: 'he-IL', flag: '🇮🇱' },
  { code: 'uk', name: 'Ukrainian', nativeName: 'Українська', speechCode: 'uk-UA', flag: '🇺🇦' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', speechCode: 'sw-TZ', flag: '🇰🇪' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', speechCode: 'bn-IN', flag: '🇧🇩' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', speechCode: 'ur-PK', flag: '🇵🇰' },
];

export const TARGET_LANGUAGES: Language[] = SOURCE_LANGUAGES.filter(l => l.code !== 'auto');

export const POPULAR_LANGUAGES = ['en', 'es', 'hi', 'kn', 'fr', 'ja', 'de', 'zh-CN', 'ar'];

export const FLOATING_LANGUAGES = [
  { code: 'en', name: 'English', greeting: 'Hello', flag: '🇺🇸', top: '8%', left: '5%', color: 'from-blue-500/20 to-cyan-500/20 border-cyan-500/40' },
  { code: 'hi', name: 'Hindi', greeting: 'नमस्ते', flag: '🇮🇳', top: '10%', left: '68%', color: 'from-amber-500/20 to-orange-500/20 border-orange-500/40' },
  { code: 'es', name: 'Spanish', greeting: 'Hola', flag: '🇪🇸', top: '46%', left: '2%', color: 'from-rose-500/20 to-red-500/20 border-rose-500/40' },
  { code: 'ja', name: 'Japanese', greeting: 'こんにちは', flag: '🇯🇵', top: '80%', left: '10%', color: 'from-emerald-500/20 to-teal-500/20 border-teal-500/40' },
  { code: 'kn', name: 'Kannada', greeting: 'ನಮಸ್ಕಾರ', flag: '🇮🇳', top: '76%', left: '65%', color: 'from-fuchsia-500/20 to-pink-500/20 border-fuchsia-500/40' },
];

export const SAMPLE_TEXTS = [
  { label: "Greeting", text: "Hello! It is wonderful to meet you. I hope you are having a fantastic day." },
  { label: "Cultural Idiom", text: "Break a leg tonight on stage! You've practiced so hard and you're going to shine." },
  { label: "Business Email", text: "Thank you for reaching out regarding our global collaboration project. Please review the attached proposal." },
  { label: "Travel & Dining", text: "Could you please recommend an authentic local dish that is not too spicy?" },
];


import React, { useState } from 'react';
import { History, Copy, Check, Trash2, ArrowRight } from 'lucide-react';
import { HistoryItem } from '../types';

interface TranslationHistoryProps {
  history: HistoryItem[];
  onClearHistory: () => void;
  onSelectHistoryItem: (item: HistoryItem) => void;
}

export const TranslationHistory: React.FC<TranslationHistoryProps> = ({
  history,
  onClearHistory,
  onSelectHistoryItem,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (history.length === 0) return null;

  const handleCopy = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="w-full bg-slate-900/80 border border-slate-800/80 rounded-3xl p-5 shadow-xl backdrop-blur-md mt-6">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-4">
        <div className="flex items-center space-x-2">
          <History className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-bold text-slate-200">Recent Translations</h3>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-400">
            {history.length}
          </span>
        </div>
        <button
          type="button"
          onClick={onClearHistory}
          className="text-xs text-slate-500 hover:text-rose-400 flex items-center space-x-1 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear History</span>
        </button>
      </div>

      <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
        {history.map((item) => (
          <div
            key={item.id}
            onClick={() => onSelectHistoryItem(item)}
            className="p-3.5 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800/80 hover:border-indigo-500/30 transition-all cursor-pointer group flex flex-col sm:flex-row sm:items-center justify-between gap-3"
          >
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-center space-x-2 text-[11px] font-semibold text-slate-400">
                <span>{item.sourceLang}</span>
                <ArrowRight className="w-3 h-3 text-slate-600" />
                <span className="text-indigo-400">{item.targetLang}</span>
                <span className="text-slate-600 font-normal">
                  • {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <p className="text-xs text-slate-300 truncate font-normal">
                {item.sourceText}
              </p>
              <p className="text-xs text-indigo-200 font-medium truncate">
                {item.translatedText}
              </p>
            </div>

            <div className="flex items-center space-x-2 shrink-0 self-end sm:self-center">
              <button
                type="button"
                onClick={(e) => handleCopy(item.translatedText, item.id, e)}
                title="Copy Translation"
                className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-indigo-600/20 text-slate-400 hover:text-indigo-300 transition-colors"
              >
                {copiedId === item.id ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

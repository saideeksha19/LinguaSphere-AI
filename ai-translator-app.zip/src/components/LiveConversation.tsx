import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Mic, MicOff, Volume2, Sparkles, User, RefreshCw, Send } from 'lucide-react';
import { VoiceWaveform } from './VoiceWaveform';
import { TARGET_LANGUAGES } from '../data/languages';
import { Language } from '../types';

interface ChatMessage {
  id: string;
  speaker: 'A' | 'B';
  originalText: string;
  originalLangName: string;
  originalFlag: string;
  translatedText: string;
  translatedLangName: string;
  translatedFlag: string;
  targetSpeechCode: string;
  timestamp: string;
}

type ConversationStatus = 'ready' | 'listening_A' | 'listening_B' | 'translating' | 'generating_voice' | 'playing_voice';

export const LiveConversation: React.FC = () => {
  const [speakerALangCode, setSpeakerALangCode] = useState<string>('es');
  const [speakerBLangCode, setSpeakerBLangCode] = useState<string>('en');

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: '1',
        speaker: 'A',
        originalText: 'Hola, ¿cómo estás? Bienvenidos a LinguaSphere AI.',
        originalLangName: 'Spanish',
        originalFlag: '🇪🇸',
        translatedText: 'Hello, how are you? Welcome to LinguaSphere AI.',
        translatedLangName: 'English',
        translatedFlag: '🇺🇸',
        targetSpeechCode: 'en-US',
        timestamp: '10:42 AM',
      },
      {
        id: '2',
        speaker: 'B',
        originalText: 'Thank you! It is incredible how instantly you can translate my speech into Japanese and Kannada.',
        originalLangName: 'English',
        originalFlag: '🇺🇸',
        translatedText: 'Gracias! Es increíble lo instantáneamente que puedes traducir mis palabras.',
        translatedLangName: 'Spanish',
        translatedFlag: '🇪🇸',
        targetSpeechCode: 'es-ES',
        timestamp: '10:43 AM',
      },
    ];
  });

  const [inputTextA, setInputTextA] = useState<string>('');
  const [inputTextB, setInputTextB] = useState<string>('');
  const [statusState, setStatusState] = useState<ConversationStatus>('ready');
  const [activeSpeakingId, setActiveSpeakingId] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const activeMicSpeakerRef = useRef<'A' | 'B' | null>(null);

  const speakerALang = TARGET_LANGUAGES.find((l) => l.code === speakerALangCode) || TARGET_LANGUAGES[1]; // Spanish default
  const speakerBLang = TARGET_LANGUAGES.find((l) => l.code === speakerBLangCode) || TARGET_LANGUAGES[0]; // English default

  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    const loadVoices = () => {
      const v = window.speechSynthesis.getVoices();
      if (v && v.length > 0) {
        setAvailableVoices(v);
      }
    };

    loadVoices();

    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
    };
  }, []);

  // Helper to play synthesized speech in the target language
  const speakText = (text: string, speechCode: string, msgId?: string, onEndCallback?: () => void) => {
    if (!text || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (onEndCallback) onEndCallback();
      setStatusState('ready');
      return;
    }

    // Cancel any ongoing speech and ensure synthesis is active
    window.speechSynthesis.cancel();
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = speechCode;
    utterance.rate = 0.95;

    // Pick matching voice if available
    const currentVoices = availableVoices.length > 0 ? availableVoices : window.speechSynthesis.getVoices();
    if (currentVoices && currentVoices.length > 0) {
      const langPrefix = speechCode.split('-')[0].toLowerCase();
      const match =
        currentVoices.find((v) => v.lang === speechCode) ||
        currentVoices.find((v) => v.lang.replace('_', '-').toLowerCase() === speechCode.toLowerCase()) ||
        currentVoices.find((v) => v.lang.toLowerCase().startsWith(langPrefix));

      if (match) {
        utterance.voice = match;
      }
    }

    // Event Handlers
    utterance.onstart = () => {
      setStatusState('playing_voice');
      if (msgId) setActiveSpeakingId(msgId);
    };

    utterance.onend = () => {
      if (msgId) setActiveSpeakingId(null);
      setStatusState('ready');
      if (onEndCallback) onEndCallback();
    };

    utterance.onerror = (err: SpeechSynthesisErrorEvent) => {
      // 'interrupted' and 'canceled' are expected when user stops or starts new speech
      if (err.error === 'interrupted' || err.error === 'canceled') {
        if (msgId) setActiveSpeakingId(null);
        return;
      }
      console.warn('LiveConversation SpeechSynthesis warning:', err.error || err);
      if (msgId) setActiveSpeakingId(null);
      setStatusState('ready');
      if (onEndCallback) onEndCallback();
    };

    // Delay slightly (100ms) after cancel() so Chrome audio engine settles cleanly
    setTimeout(() => {
      try {
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        console.warn('Failed to call speechSynthesis.speak:', e);
        setStatusState('ready');
      }
    }, 100);
  };

  // Toggle Microphone for Speaker A or B
  const toggleMic = (speaker: 'A' | 'B') => {
    const isCurrentlyListeningThis =
      (speaker === 'A' && statusState === 'listening_A') ||
      (speaker === 'B' && statusState === 'listening_B');

    // If currently listening on this speaker, stop recording
    if (isCurrentlyListeningThis) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      setStatusState('ready');
      activeMicSpeakerRef.current = null;
      return;
    }

    // Stop any existing synthesis or speech recognition
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setActiveSpeakingId(null);

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      // Speech recognition fallback
      const sampleText =
        speaker === 'A'
          ? speakerALang.code === 'es'
            ? 'Me gustaría reservar una mesa para dos personas.'
            : 'Hello, how can I help you today?'
          : speakerBLang.code === 'en'
          ? 'Sure, I would be happy to assist you with that.'
          : 'Namaste! Main aapki kya sahayata kar sakta hoon?';

      if (speaker === 'A') setInputTextA(sampleText);
      else setInputTextB(sampleText);

      return;
    }

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;

      const targetLangObj = speaker === 'A' ? speakerALang : speakerBLang;
      recognition.lang = targetLangObj.speechCode || 'en-US';

      recognition.onstart = () => {
        activeMicSpeakerRef.current = speaker;
        setStatusState(speaker === 'A' ? 'listening_A' : 'listening_B');
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        if (speaker === 'A') {
          setInputTextA(currentTranscript);
        } else {
          setInputTextB(currentTranscript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setStatusState('ready');
        activeMicSpeakerRef.current = null;
      };

      recognition.onend = () => {
        setStatusState('ready');
        activeMicSpeakerRef.current = null;
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Failed to initiate speech recognition:', err);
      setStatusState('ready');
      activeMicSpeakerRef.current = null;
    }
  };

  // Process a speaker turn (translate -> speak -> add to log)
  const handleSendTurn = async (speaker: 'A' | 'B') => {
    const rawText = speaker === 'A' ? inputTextA : inputTextB;
    if (!rawText.trim() || statusState === 'translating' || statusState === 'generating_voice') return;

    // Release microphone if active
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
    activeMicSpeakerRef.current = null;

    // 1. Set state to Translating
    setStatusState('translating');

    const sourceLangObj = speaker === 'A' ? speakerALang : speakerBLang;
    const targetLangObj = speaker === 'A' ? speakerBLang : speakerALang;

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: rawText,
          sourceLang: sourceLangObj.name,
          targetLang: targetLangObj.name,
        }),
      });

      const data = await response.json();
      const translatedText = data.translatedText || rawText;

      // 2. Clear input
      if (speaker === 'A') setInputTextA('');
      else setInputTextB('');

      // 3. Set state to Generating Voice
      setStatusState('generating_voice');

      const msgId = Date.now().toString();
      const newMsg: ChatMessage = {
        id: msgId,
        speaker,
        originalText: rawText,
        originalLangName: sourceLangObj.name,
        originalFlag: sourceLangObj.flag,
        translatedText,
        translatedLangName: targetLangObj.name,
        translatedFlag: targetLangObj.flag,
        targetSpeechCode: targetLangObj.speechCode,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, newMsg]);

      // 4. Speak target audio automatically (utterance.onstart sets statusState to 'playing_voice')
      speakText(translatedText, targetLangObj.speechCode, msgId);
    } catch (error) {
      console.error('Conversation translation error:', error);
      setStatusState('ready');
    }
  };

  return (
    <section id="conversation" className="w-full py-4 sm:py-8 relative">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-semibold">
            <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
            <span>Dual-Avatar Live Translation</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Live Conversation Mode
          </h2>

          <p className="text-slate-400 text-xs sm:text-sm">
            Experience fluid, real-time bilingual dialogue. Select any languages for Speaker A and Speaker B to talk across barriers.
          </p>

          {/* Dynamic Status Indicator Badge */}
          <div className="pt-2 flex items-center justify-center">
            <div
              className={`inline-flex items-center space-x-2 px-4 py-1.5 rounded-full text-xs font-bold transition-all border shadow-lg ${
                statusState === 'listening_A' || statusState === 'listening_B'
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                  : statusState === 'translating'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                  : statusState === 'generating_voice'
                  ? 'bg-purple-500/20 text-purple-300 border-purple-500/40 animate-pulse'
                  : statusState === 'playing_voice'
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 animate-pulse'
                  : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  statusState === 'ready' ? 'bg-emerald-400' : 'bg-current animate-ping'
                }`}
              />
              <span>
                {statusState === 'listening_A'
                  ? 'Listening to Speaker A...'
                  : statusState === 'listening_B'
                  ? 'Listening to Speaker B...'
                  : statusState === 'translating'
                  ? 'Translating with Gemini AI...'
                  : statusState === 'generating_voice'
                  ? 'Generating Voice...'
                  : statusState === 'playing_voice'
                  ? 'Playing Translation...'
                  : 'Ready for Speech'}
              </span>
            </div>
          </div>
        </div>

        {/* Conversation Box */}
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-4 sm:p-7 shadow-2xl backdrop-blur-xl">
          
          {/* Avatar Header Row with Switchable Language Dropdowns */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-6 mb-6 border-b border-slate-800/80">
            
            {/* Speaker A Avatar & Language Selector */}
            <div className="flex items-center justify-between bg-slate-950/60 p-3 rounded-2xl border border-indigo-500/30">
              <div className="flex items-center space-x-3 min-w-0">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-500 p-0.5 shrink-0 shadow-lg shadow-indigo-500/20">
                  <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                    <User className="w-5 h-5 text-indigo-400" />
                  </div>
                </div>
                <div className="min-w-0">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-100 truncate">Speaker A (Elena)</h4>
                  <p className="text-[10px] text-indigo-300 font-medium">{speakerALang.name} Native</p>
                </div>
              </div>

              {/* Speaker A Language Dropdown */}
              <div className="shrink-0 ml-2">
                <select
                  value={speakerALangCode}
                  onChange={(e) => setSpeakerALangCode(e.target.value)}
                  className="bg-slate-900 hover:bg-slate-850 text-slate-100 text-xs font-semibold rounded-xl px-2.5 py-1.5 border border-indigo-500/40 focus:outline-none focus:border-indigo-400 cursor-pointer shadow-sm"
                >
                  {TARGET_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code} className="bg-slate-900 text-slate-100">
                      {lang.flag} {lang.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Speaker B Avatar & Language Selector */}
            <div className="flex items-center justify-between bg-slate-950/60 p-3 rounded-2xl border border-cyan-500/30">
              <div className="flex items-center space-x-3 min-w-0">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-cyan-500 to-teal-500 p-0.5 shrink-0 shadow-lg shadow-cyan-500/20">
                  <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                    <User className="w-5 h-5 text-cyan-400" />
                  </div>
                </div>
                <div className="min-w-0">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-100 truncate">Speaker B (Alex)</h4>
                  <p className="text-[10px] text-cyan-300 font-medium">{speakerBLang.name} Native</p>
                </div>
              </div>

              {/* Speaker B Language Dropdown */}
              <div className="shrink-0 ml-2">
                <select
                  value={speakerBLangCode}
                  onChange={(e) => setSpeakerBLangCode(e.target.value)}
                  className="bg-slate-900 hover:bg-slate-850 text-slate-100 text-xs font-semibold rounded-xl px-2.5 py-1.5 border border-cyan-500/40 focus:outline-none focus:border-cyan-400 cursor-pointer shadow-sm"
                >
                  {TARGET_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code} className="bg-slate-900 text-slate-100">
                      {lang.flag} {lang.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

          </div>

          {/* Dialogue Log */}
          <div className="space-y-4 max-h-[360px] overflow-y-auto pr-1">
            {messages.map((msg) => {
              const isA = msg.speaker === 'A';
              const isSpeaking = activeSpeakingId === msg.id;

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isA ? 'items-start' : 'items-end'}`}
                >
                  <div
                    className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 border space-y-2 transition-all ${
                      isA
                        ? 'bg-indigo-950/40 border-indigo-800/40 text-slate-200'
                        : 'bg-cyan-950/40 border-cyan-800/40 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] font-semibold text-slate-400 pb-1 border-b border-slate-800/60">
                      <span>
                        {isA ? `Speaker A (${msg.originalLangName})` : `Speaker B (${msg.originalLangName})`} {msg.originalFlag}
                      </span>
                      <span>{msg.timestamp}</span>
                    </div>

                    {/* Original phrase */}
                    <p className="text-xs text-slate-300 font-normal italic">
                      "{msg.originalText}"
                    </p>

                    {/* AI Translated Phrase */}
                    <div className="pt-2 flex items-start justify-between gap-3 border-t border-slate-800/80">
                      <div className="space-y-0.5 min-w-0">
                        <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider block">
                          Translated ({msg.translatedLangName}) {msg.translatedFlag}
                        </span>
                        <p className="text-xs sm:text-sm font-semibold text-white leading-relaxed">
                          {msg.translatedText}
                        </p>
                      </div>

                      {/* Replay Audio Button in Target Language */}
                      <button
                        type="button"
                        onClick={() => speakText(msg.translatedText, msg.targetSpeechCode, msg.id)}
                        className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 shrink-0 transition-colors cursor-pointer"
                        title={`Replay audio in ${msg.translatedLangName}`}
                      >
                        <Volume2 className={`w-4 h-4 ${isSpeaking ? 'text-cyan-400 animate-pulse' : ''}`} />
                      </button>
                    </div>

                    <VoiceWaveform isActive={isSpeaking} color={isA ? '#818cf8' : '#22d3ee'} />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Interactive Input & Speech Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-6 pt-6 border-t border-slate-800/80">
            
            {/* Speaker A Input */}
            <div className="flex items-center space-x-2 bg-slate-950/80 p-2 rounded-2xl border border-indigo-900/50">
              <button
                type="button"
                onClick={() => toggleMic('A')}
                className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                  statusState === 'listening_A'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                    : 'bg-slate-900 text-indigo-400 border-indigo-500/30 hover:bg-slate-850'
                }`}
                title={`Speak in ${speakerALang.name}`}
              >
                {statusState === 'listening_A' ? <MicOff className="w-4 h-4 text-rose-400" /> : <Mic className="w-4 h-4" />}
              </button>

              <input
                type="text"
                value={inputTextA}
                onChange={(e) => setInputTextA(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendTurn('A')}
                placeholder={`Type or speak in ${speakerALang.name} (Speaker A)...`}
                className="w-full bg-transparent text-xs text-slate-100 placeholder-slate-500 px-2 focus:outline-none"
              />

              <button
                type="button"
                onClick={() => handleSendTurn('A')}
                disabled={statusState === 'translating' || statusState === 'generating_voice' || !inputTextA.trim()}
                className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shrink-0 transition-all cursor-pointer disabled:opacity-40 flex items-center space-x-1"
              >
                <span>Send A</span>
                <Send className="w-3 h-3" />
              </button>
            </div>

            {/* Speaker B Input */}
            <div className="flex items-center space-x-2 bg-slate-950/80 p-2 rounded-2xl border border-cyan-900/50">
              <button
                type="button"
                onClick={() => toggleMic('B')}
                className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                  statusState === 'listening_B'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                    : 'bg-slate-900 text-cyan-400 border-cyan-500/30 hover:bg-slate-850'
                }`}
                title={`Speak in ${speakerBLang.name}`}
              >
                {statusState === 'listening_B' ? <MicOff className="w-4 h-4 text-rose-400" /> : <Mic className="w-4 h-4" />}
              </button>

              <input
                type="text"
                value={inputTextB}
                onChange={(e) => setInputTextB(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendTurn('B')}
                placeholder={`Type or speak in ${speakerBLang.name} (Speaker B)...`}
                className="w-full bg-transparent text-xs text-slate-100 placeholder-slate-500 px-2 focus:outline-none"
              />

              <button
                type="button"
                onClick={() => handleSendTurn('B')}
                disabled={statusState === 'translating' || statusState === 'generating_voice' || !inputTextB.trim()}
                className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shrink-0 transition-all cursor-pointer disabled:opacity-40 flex items-center space-x-1"
              >
                <span>Send B</span>
                <Send className="w-3 h-3" />
              </button>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};

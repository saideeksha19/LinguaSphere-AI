import React from 'react';
import { Globe, Sparkles, History, MessageSquare, Menu, X } from 'lucide-react';

interface HeaderProps {
  historyCount: number;
  onOpenHistory: () => void;
}

export const Header: React.FC<HeaderProps> = ({ historyCount, onOpenHistory }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState<boolean>(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-xl bg-slate-950/80 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between">
        
        {/* Brand Logo */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-cyan-400 p-0.5 shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Globe className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <span className="text-lg sm:text-xl font-extrabold text-white tracking-tight flex items-center space-x-1">
              <span>LinguaSphere</span>
              <span className="bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent">
                AI
              </span>
            </span>
            <span className="block text-[10px] text-slate-400 font-medium">
              3D Neural Translation Platform
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center space-x-6 text-xs sm:text-sm font-medium text-slate-300">
          <button
            type="button"
            onClick={() => scrollTo('translator')}
            className="hover:text-cyan-300 transition-colors cursor-pointer"
          >
            3D Translator
          </button>
          <button
            type="button"
            onClick={() => scrollTo('conversation')}
            className="hover:text-cyan-300 transition-colors cursor-pointer"
          >
            Live Conversation
          </button>
          <button
            type="button"
            onClick={() => scrollTo('features')}
            className="hover:text-cyan-300 transition-colors cursor-pointer"
          >
            Features
          </button>
        </nav>

        {/* Action Controls */}
        <div className="flex items-center space-x-3">
          {/* Gemini Badge */}
          <div className="hidden sm:flex items-center space-x-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Gemini 3.6 Flash</span>
          </div>

          {/* History Drawer Trigger */}
          <button
            type="button"
            onClick={onOpenHistory}
            className="relative px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 hover:border-indigo-500/40 text-xs font-medium transition-colors flex items-center space-x-1.5 cursor-pointer"
          >
            <History className="w-4 h-4 text-slate-400" />
            <span className="hidden sm:inline">History</span>
            {historyCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] font-bold flex items-center justify-center">
                {historyCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl bg-slate-900 text-slate-300 border border-slate-800"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-950 border-b border-slate-800 px-4 py-4 space-y-3">
          <button
            type="button"
            onClick={() => scrollTo('translator')}
            className="block w-full text-left py-2 text-sm text-slate-200 hover:text-cyan-300"
          >
            3D Translator
          </button>
          <button
            type="button"
            onClick={() => scrollTo('conversation')}
            className="block w-full text-left py-2 text-sm text-slate-200 hover:text-cyan-300"
          >
            Live Conversation
          </button>
          <button
            type="button"
            onClick={() => scrollTo('features')}
            className="block w-full text-left py-2 text-sm text-slate-200 hover:text-cyan-300"
          >
            Features
          </button>
        </div>
      )}
    </header>
  );
};

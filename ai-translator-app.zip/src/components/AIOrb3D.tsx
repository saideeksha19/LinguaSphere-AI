import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface AIOrb3DProps {
  isTranslating?: boolean;
}

export const AIOrb3D: React.FC<AIOrb3DProps> = ({ isTranslating = false }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const orbMaterialRef = useRef<THREE.MeshBasicMaterial | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth || 120;
    const height = containerRef.current.clientHeight || 120;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    camera.position.z = 12;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Clear container to prevent duplicate canvas elements
    if (containerRef.current) {
      while (containerRef.current.firstChild) {
        containerRef.current.removeChild(containerRef.current.firstChild);
      }
      containerRef.current.appendChild(renderer.domElement);
    }

    const dom = renderer.domElement;

    const group = new THREE.Group();
    scene.add(group);

    // 1. Central Core Mesh with Wireframe Outer Lattice
    const coreGeo = new THREE.SphereGeometry(3.2, 32, 32);
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0x6366f1,
      wireframe: true,
      transparent: true,
      opacity: 0.85,
    });
    orbMaterialRef.current = coreMat;
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    group.add(coreMesh);

    // 2. Inner Glowing Core
    const innerGeo = new THREE.SphereGeometry(2.4, 24, 24);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      transparent: true,
      opacity: 0.9,
    });
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    group.add(innerMesh);

    // 3. Orbiting Particle Ring
    const ringParticlesCount = 80;
    const ringGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(ringParticlesCount * 3);

    for (let i = 0; i < ringParticlesCount; i++) {
      const angle = (i / ringParticlesCount) * Math.PI * 2;
      const radius = 4.8 + (Math.random() - 0.5) * 0.4;
      positions[i * 3] = Math.cos(angle) * radius;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 0.6;
      positions[i * 3 + 2] = Math.sin(angle) * radius;
    }

    ringGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const ringMat = new THREE.PointsMaterial({
      color: 0x06b6d4,
      size: 0.25,
      transparent: true,
      opacity: 0.85,
    });
    const ringPoints = new THREE.Points(ringGeo, ringMat);
    group.add(ringPoints);

    let frameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Rotation speed increases when translating
      const rotSpeed = isTranslating ? 0.04 : 0.015;
      group.rotation.y += rotSpeed;
      group.rotation.x = Math.sin(elapsedTime * 0.8) * 0.2;

      // Ring counter-rotation
      ringPoints.rotation.y -= rotSpeed * 1.5;

      // Pulsing Scale
      const scaleBase = 1 + Math.sin(elapsedTime * (isTranslating ? 6 : 2)) * (isTranslating ? 0.15 : 0.05);
      group.scale.set(scaleBase, scaleBase, scaleBase);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && dom && dom.parentNode === containerRef.current) {
        containerRef.current.removeChild(dom);
      }
      renderer.dispose();
    };
  }, [isTranslating]);

  return (
    <div className="relative w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center">
      <div ref={containerRef} className="w-full h-full" />
      {/* Glow Backdrop */}
      <div
        className={`absolute inset-0 rounded-full blur-xl pointer-events-none transition-all duration-300 ${
          isTranslating
            ? 'bg-cyan-500/40 scale-125 animate-pulse'
            : 'bg-indigo-500/20 scale-100'
        }`}
      />
    </div>
  );
};

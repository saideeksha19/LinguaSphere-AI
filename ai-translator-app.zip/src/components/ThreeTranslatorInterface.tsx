import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeftRight,
  Copy,
  Check,
  Trash2,
  Volume2,
  Sparkles,
  RefreshCw,
  Info,
  Mic,
  MicOff,
  SlidersHorizontal,
  ArrowRight,
  Globe,
  Camera,
  MessageSquare
} from 'lucide-react';
import { SOURCE_LANGUAGES, TARGET_LANGUAGES, POPULAR_LANGUAGES, SAMPLE_TEXTS } from '../data/languages';
import { FormalityStyle, HistoryItem, TranslationResponse } from '../types';
import { LanguageSelector } from './LanguageSelector';
import { AIOrb3D } from './AIOrb3D';
import { VoiceWaveform } from './VoiceWaveform';

interface ThreeTranslatorInterfaceProps {
  onAddHistory: (item: HistoryItem) => void;
  selectedTargetFromBubble?: string;
}

export const ThreeTranslatorInterface: React.FC<ThreeTranslatorInterfaceProps> = ({
  onAddHistory,
  selectedTargetFromBubble,
}) => {
  const [sourceLang, setSourceLang] = useState<string>('en');
  const [targetLang, setTargetLang] = useState<string>('es');
  const [inputText, setInputText] = useState<string>('');
  const [translatedText, setTranslatedText] = useState<string>('');
  const [detectedLanguage, setDetectedLanguage] = useState<string>('');
  const [pronunciation, setPronunciation] = useState<string>('');
  const [contextNote, setContextNote] = useState<string>('');
  const [formality, setFormality] = useState<FormalityStyle>('default');

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSpeakingSource, setIsSpeakingSource] = useState<boolean>(false);
  const [isSpeakingTarget, setIsSpeakingTarget] = useState<boolean>(false);

  const recognitionRef = useRef<any>(null);

  // Synchronize when user clicks a floating bubble in the hero section
  useEffect(() => {
    if (selectedTargetFromBubble) {
      setTargetLang(selectedTargetFromBubble);
    }
  }, [selectedTargetFromBubble]);

  // Speech Recognition Setup
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;

        recognition.onstart = () => {
          setIsListening(true);
          setErrorMsg('');
        };

        recognition.onresult = (event: any) => {
          let currentTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript;
          }
          setInputText(currentTranscript);
        };

        recognition.onerror = (event: any) => {
          console.warn('Speech recognition error:', event.error);
          setIsListening(false);
          if (event.error === 'not-allowed') {
            setErrorMsg('Microphone access was denied. Please allow microphone permissions in your browser.');
          }
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      }
    }
  }, []);

  const toggleMic = () => {
    if (!recognitionRef.current) {
      // Fallback if browser doesn't support Web Speech API
      if (!isListening) {
        setIsListening(true);
        setInputText('Hello! I would love to explore the city today and taste authentic cuisine.');
        setTimeout(() => setIsListening(false), 2000);
      } else {
        setIsListening(false);
      }
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      try {
        const langObj = SOURCE_LANGUAGES.find((l) => l.code === sourceLang);
        recognitionRef.current.lang = langObj?.speechCode || 'en-US';
        recognitionRef.current.start();
      } catch (e) {
        console.error('Failed to start speech recognition', e);
        setIsListening(false);
      }
    }
  };

  // Perform Gemini AI Translation
  const handleTranslate = async () => {
    if (!inputText.trim()) {
      setErrorMsg('Please enter or speak text to translate.');
      return;
    }

    setIsLoading(true);
    setErrorMsg('');
    setTranslatedText('');
    setPronunciation('');
    setContextNote('');

    const targetLangObj = TARGET_LANGUAGES.find((l) => l.code === targetLang);
    const sourceLangObj = SOURCE_LANGUAGES.find((l) => l.code === sourceLang);

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: inputText,
          sourceLang: sourceLang === 'auto' ? 'auto' : sourceLangObj?.name,
          targetLang: targetLangObj?.name || 'Spanish',
          formality,
        }),
      });

      const data: TranslationResponse = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Failed to complete translation.');
      }

      setTranslatedText(data.translatedText);
      setDetectedLanguage(data.detectedLanguage || '');
      setPronunciation(data.pronunciation || '');
      setContextNote(data.contextNote || '');

      // Add item to history
      onAddHistory({
        id: Date.now().toString(),
        sourceText: inputText,
        translatedText: data.translatedText,
        sourceLang: sourceLang === 'auto' ? (data.detectedLanguage || 'Auto') : (sourceLangObj?.name || sourceLang),
        targetLang: targetLangObj?.name || targetLang,
        detectedLanguage: data.detectedLanguage,
        pronunciation: data.pronunciation,
        contextNote: data.contextNote,
        timestamp: Date.now(),
      });
    } catch (err: any) {
      console.error('Translation error:', err);
      const msg = err.message || 'Error communicating with translation server.';
      setErrorMsg(msg);
    } finally {
      setIsLoading(false);
    }
  };

  // Swap source and target languages
  const handleSwapLanguages = () => {
    if (sourceLang === 'auto') {
      const newSource = targetLang;
      const newTarget = newSource === 'en' ? 'es' : 'en';
      setSourceLang(newSource);
      setTargetLang(newTarget);
    } else {
      const temp = sourceLang;
      setSourceLang(targetLang);
      setTargetLang(temp);
    }

    if (translatedText) {
      setInputText(translatedText);
      setTranslatedText(inputText);
      setPronunciation('');
      setContextNote('');
    }
  };

  const handleClear = () => {
    setInputText('');
    setTranslatedText('');
    setDetectedLanguage('');
    setPronunciation('');
    setContextNote('');
    setErrorMsg('');
  };

  const handleCopy = () => {
    if (!translatedText) return;
    navigator.clipboard.writeText(translatedText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleSpeak = (text: string, langCode: string, isSource: boolean) => {
    if (!text || typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    // Reset indicator states
    setIsSpeakingSource(false);
    setIsSpeakingTarget(false);

    // Cancel ongoing speech synthesis
    window.speechSynthesis.cancel();

    if (isSource) setIsSpeakingSource(true);
    else setIsSpeakingTarget(true);

    // Find language object for BCP-47 speech code
    let langObj = (isSource ? SOURCE_LANGUAGES : TARGET_LANGUAGES).find((l) => l.code === langCode);
    if (isSource && langCode === 'auto' && detectedLanguage) {
      const match = SOURCE_LANGUAGES.find(
        (l) => l.name.toLowerCase() === detectedLanguage.toLowerCase() || l.code === detectedLanguage.toLowerCase()
      );
      if (match) langObj = match;
    }

    const speechLang = langObj?.speechCode || 'en-US';

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = speechLang;
    utterance.rate = 0.95;

    const playSpeech = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices && voices.length > 0) {
        const langPrefix = speechLang.split('-')[0];
        const match =
          voices.find((v) => v.lang === speechLang) ||
          voices.find((v) => v.lang.startsWith(langPrefix));
        if (match) {
          utterance.voice = match;
        }
      }

      utterance.onend = () => {
        setIsSpeakingSource(false);
        setIsSpeakingTarget(false);
      };

      utterance.onerror = (e: SpeechSynthesisErrorEvent) => {
        if (e.error === 'interrupted' || e.error === 'canceled') {
          setIsSpeakingSource(false);
          setIsSpeakingTarget(false);
          return;
        }
        console.warn('Speech synthesis warning:', e.error || e);
        setIsSpeakingSource(false);
        setIsSpeakingTarget(false);
      };

      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      window.speechSynthesis.speak(utterance);
    };

    // Delay briefly so speechSynthesis.cancel() finishes cleanly before speak()
    setTimeout(playSpeech, 50);
  };

  const wordCount = inputText.trim() ? inputText.trim().split(/\s+/).length : 0;

  return (
    <div id="translator" className="w-full relative my-2 sm:my-4">
      {/* Outer Futuristic Glowing Container */}
      <div className="relative rounded-3xl p-1 bg-gradient-to-r from-indigo-500/30 via-purple-500/30 to-cyan-500/30 shadow-2xl shadow-indigo-950/80 backdrop-blur-2xl">
        <div className="bg-slate-950/90 rounded-[22px] p-4 sm:p-7 border border-slate-800/80">
          
          {/* Header Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-5 mb-6 border-b border-slate-800/80">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-cyan-400 p-0.5 shadow-md flex items-center justify-center">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                </div>
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center space-x-2">
                  <span>3D AI Translation Engine</span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                    Real-time
                  </span>
                </h3>
                <p className="text-xs text-slate-400">Contextual translation powered by Gemini 3.6 Flash</p>
              </div>
            </div>

            {/* Tone/Formality Selector */}
            <div className="flex items-center space-x-2 bg-slate-900/90 p-1.5 rounded-xl border border-slate-800">
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400 ml-1" />
              <span className="text-xs font-medium text-slate-400 hidden sm:inline">Tone:</span>
              <div className="inline-flex p-0.5 rounded-lg bg-slate-950 border border-slate-800">
                {(['default', 'formal', 'casual'] as FormalityStyle[]).map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFormality(f)}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium capitalize transition-all cursor-pointer ${
                      formality === f
                        ? 'bg-indigo-600 text-white shadow'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {f === 'default' ? 'Natural' : f}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Core Translation Grid: Input Panel | Central 3D AI Orb | Output Panel */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
            
            {/* LEFT: English / Source Input Panel */}
            <div className="lg:col-span-5 flex flex-col rounded-2xl bg-slate-900/60 border border-slate-800 p-4 sm:p-5 relative transition-all focus-within:border-indigo-500/60 focus-within:ring-1 focus-within:ring-indigo-500/30">
              
              {/* Language Selector Header */}
              <div className="pb-3 mb-3 border-b border-slate-800/80 flex items-center justify-between">
                <div className="flex-1">
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Source Language
                  </label>
                  <LanguageSelector
                    id="source-lang-select"
                    languages={SOURCE_LANGUAGES}
                    selectedLanguage={sourceLang}
                    onSelectLanguage={setSourceLang}
                    popularCodes={POPULAR_LANGUAGES}
                    isSource={true}
                  />
                </div>
              </div>

              {/* Text Area */}
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Enter or speak text to translate in real-time..."
                className="w-full flex-1 bg-transparent text-slate-100 placeholder-slate-500 text-base resize-none focus:outline-none min-h-[160px] leading-relaxed"
              />

              {/* Sample Quick Prompts */}
              {!inputText && (
                <div className="my-2 flex flex-wrap gap-1.5">
                  <span className="text-[11px] text-slate-500 block w-full mb-1">Sample prompts:</span>
                  {SAMPLE_TEXTS.map((sample, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setInputText(sample.text)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800/60 hover:bg-slate-800 text-[11px] text-slate-300 hover:text-white transition-colors cursor-pointer border border-slate-700/40"
                    >
                      {sample.label}
                    </button>
                  ))}
                </div>
              )}

              {/* Controls Footer */}
              <div className="flex items-center justify-between pt-3 mt-auto border-t border-slate-800/80 text-xs text-slate-400">
                <div className="flex items-center space-x-3">
                  {/* Microphone Button */}
                  <button
                    type="button"
                    onClick={toggleMic}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center space-x-1.5 ${
                      isListening
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                        : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700/80 hover:text-indigo-400'
                    }`}
                    title={isListening ? 'Stop listening' : 'Start voice input'}
                  >
                    {isListening ? <MicOff className="w-4 h-4 text-rose-400" /> : <Mic className="w-4 h-4" />}
                    <span className="text-xs font-medium">{isListening ? 'Listening...' : 'Voice'}</span>
                  </button>

                  <VoiceWaveform isActive={isListening || isSpeakingSource} color="#818cf8" />
                </div>

                <div className="flex items-center space-x-2">
                  <span className="text-[11px]">{wordCount} words</span>
                  {inputText && (
                    <button
                      type="button"
                      onClick={() => handleSpeak(inputText, sourceLang, true)}
                      title="Listen to input text"
                      className={`p-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-indigo-400 transition-colors ${
                        isSpeakingSource ? 'text-indigo-400 animate-pulse' : ''
                      }`}
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  )}
                  {inputText && (
                    <button
                      type="button"
                      onClick={handleClear}
                      className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
                      title="Clear text"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* CENTER: Glowing 3D AI Orb & Language Swap Button */}
            <div className="lg:col-span-2 flex flex-col items-center justify-center py-4 lg:py-0 space-y-4">
              
              {/* 3D AI Orb */}
              <AIOrb3D isTranslating={isLoading} />

              {/* Swap Languages Button */}
              <button
                type="button"
                onClick={handleSwapLanguages}
                className="p-3 rounded-2xl bg-gradient-to-tr from-slate-900 to-slate-800 hover:from-indigo-900 hover:to-slate-800 text-slate-200 hover:text-cyan-300 border border-slate-700/80 hover:border-cyan-500/40 shadow-lg transition-all duration-300 active:scale-95 group cursor-pointer"
                title="Swap Source and Target Languages"
              >
                <ArrowLeftRight className="w-5 h-5 group-hover:rotate-180 transition-transform duration-500" />
              </button>

              <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest">
                Gemini AI
              </span>
            </div>

            {/* RIGHT: Spanish / Target Output Panel */}
            <div className="lg:col-span-5 flex flex-col rounded-2xl bg-slate-900/60 border border-slate-800 p-4 sm:p-5 relative min-h-[220px]">
              
              {/* Target Language Selector */}
              <div className="pb-3 mb-3 border-b border-slate-800/80 flex items-center justify-between">
                <div className="flex-1">
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Target Language
                  </label>
                  <LanguageSelector
                    id="target-lang-select"
                    languages={TARGET_LANGUAGES}
                    selectedLanguage={targetLang}
                    onSelectLanguage={setTargetLang}
                    popularCodes={POPULAR_LANGUAGES}
                    isSource={false}
                  />
                </div>
              </div>

              {/* Output Content */}
              <div className="flex-1 relative min-h-[160px] my-1">
                {isLoading ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center space-y-3">
                    <div className="w-8 h-8 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin" />
                    <p className="text-xs text-cyan-300 font-medium animate-pulse">
                      Gemini AI analyzing context & translating...
                    </p>
                  </div>
                ) : translatedText ? (
                  <div className="space-y-3">
                    <p className="text-slate-100 text-base leading-relaxed whitespace-pre-wrap select-text font-sans">
                      {translatedText}
                    </p>

                    {/* Romanized Pronunciation */}
                    {pronunciation && (
                      <div className="pt-2 border-t border-slate-800/80">
                        <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                          Phonetic Pronunciation
                        </span>
                        <p className="text-xs text-cyan-300 font-mono bg-cyan-950/30 px-3 py-1.5 rounded-lg border border-cyan-900/40">
                          {pronunciation}
                        </p>
                      </div>
                    )}

                    {/* Context & Nuance Note */}
                    {contextNote && (
                      <div className="pt-2">
                        <div className="flex items-start space-x-2 bg-indigo-950/30 p-2.5 rounded-xl border border-indigo-900/40 text-xs text-slate-300">
                          <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-semibold text-indigo-300 block mb-0.5">Context Preserved</span>
                            <p className="text-slate-400 text-[11px] leading-relaxed">{contextNote}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                    <Globe className="w-8 h-8 mb-2 stroke-[1.5] text-slate-600" />
                    <p className="text-xs text-slate-400 max-w-xs">
                      AI translation output will appear here with preserved meaning & tone.
                    </p>
                  </div>
                )}
              </div>

              {/* Controls Footer */}
              <div className="flex items-center justify-between pt-3 mt-auto border-t border-slate-800/80 text-xs text-slate-400">
                <div className="flex items-center space-x-2">
                  {translatedText && (
                    <button
                      type="button"
                      onClick={() => handleSpeak(translatedText, targetLang, false)}
                      className={`p-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-cyan-400 transition-colors flex items-center space-x-1.5 cursor-pointer ${
                        isSpeakingTarget ? 'text-cyan-400 animate-pulse' : ''
                      }`}
                      title="Listen to translated output"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span className="text-xs">Audio</span>
                    </button>
                  )}
                  <VoiceWaveform isActive={isSpeakingTarget} color="#22d3ee" />
                </div>

                {translatedText && (
                  <button
                    type="button"
                    onClick={handleCopy}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isCopied
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700/80'
                    }`}
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-400" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                )}
              </div>

            </div>

          </div>

          {/* Error Banner if any */}
          {errorMsg && (
            <div className="mt-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-rose-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
              <div className="flex items-center space-x-2 self-end sm:self-auto">
                <button
                  type="button"
                  onClick={handleTranslate}
                  className="px-3 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-xs font-semibold border border-rose-500/30 flex items-center space-x-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Retry</span>
                </button>
                <button
                  type="button"
                  onClick={() => setErrorMsg('')}
                  className="text-rose-400 hover:text-rose-200 font-bold px-1"
                >
                  ×
                </button>
              </div>
            </div>
          )}

          {/* Action Bar */}
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800/80">
            <button
              type="button"
              onClick={handleClear}
              disabled={!inputText && !translatedText}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center space-x-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset Input & Output</span>
            </button>

            <button
              type="button"
              onClick={handleTranslate}
              disabled={isLoading || !inputText.trim()}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white text-sm font-bold shadow-xl shadow-indigo-600/30 transition-all duration-200 active:scale-98 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Translating with Gemini AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-cyan-200" />
                  <span>Translate Now</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};

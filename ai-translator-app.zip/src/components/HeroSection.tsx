import React from 'react';
import { Sparkles, Globe, ArrowRight, Zap, Play } from 'lucide-react';
import { Globe3D } from './Globe3D';
import { FLOATING_LANGUAGES } from '../data/languages';

interface HeroSectionProps {
  onSelectBubbleLanguage?: (langCode: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onSelectBubbleLanguage }) => {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative w-full py-6 sm:py-10 overflow-hidden">
      {/* Background Neon Grid Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.25),rgba(255,255,255,0))]" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Text Column */}
          <div className="lg:col-span-6 text-center lg:text-left space-y-6">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-indigo-500/30 text-indigo-300 text-xs font-semibold shadow-lg shadow-indigo-500/10 backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
              <span>Next-Gen Neural Translation • LinguaSphere AI</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.1]">
              Speak Any Language.{' '}
              <span className="bg-gradient-to-r from-indigo-400 via-cyan-300 to-purple-400 bg-clip-text text-transparent">
                Connect With Anyone.
              </span>
            </h1>

            <p className="text-slate-300 text-base sm:text-lg max-w-xl mx-auto lg:mx-0 font-normal leading-relaxed">
              Real-time AI translation for global communication. Preserve true human context, cultural idiom, and vocal cadence across 100+ languages with Gemini AI.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
              <button
                type="button"
                onClick={() => scrollToSection('translator')}
                className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white text-sm font-bold shadow-xl shadow-indigo-500/25 transition-all duration-200 active:scale-95 flex items-center justify-center space-x-2 group cursor-pointer"
              >
                <span>Start Translating</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('features')}
                className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-800 hover:border-indigo-500/40 text-sm font-medium transition-all backdrop-blur-md flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Zap className="w-4 h-4 text-cyan-400" />
                <span>Explore Features</span>
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-800/80 max-w-md mx-auto lg:mx-0">
              <div>
                <div className="text-xl font-bold text-slate-100">100+</div>
                <div className="text-[11px] text-slate-400">Languages</div>
              </div>
              <div>
                <div className="text-xl font-bold text-cyan-400">&lt;200ms</div>
                <div className="text-[11px] text-slate-400">Latency</div>
              </div>
              <div>
                <div className="text-xl font-bold text-indigo-400">99.8%</div>
                <div className="text-[11px] text-slate-400">Accuracy</div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive 3D Globe with Floating Language Bubbles */}
          <div className="lg:col-span-6 relative flex items-center justify-center w-full max-w-full overflow-hidden py-2">
            
            {/* 3D Globe Canvas */}
            <Globe3D />

            {/* Floating Language Bubbles */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {FLOATING_LANGUAGES.map((item) => (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => {
                    if (onSelectBubbleLanguage) onSelectBubbleLanguage(item.code);
                    scrollToSection('translator');
                  }}
                  title={`Click to translate in ${item.name}`}
                  style={{
                    top: item.top,
                    left: item.left,
                  }}
                  className={`pointer-events-auto absolute px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full bg-slate-950/85 border backdrop-blur-xl shadow-xl hover:scale-110 active:scale-95 transition-all duration-300 cursor-pointer flex items-center space-x-1.5 sm:space-x-2 bg-gradient-to-r ${item.color} group animate-bounce-slow`}
                >
                  <span className="text-xs sm:text-sm">{item.flag}</span>
                  <div className="text-left">
                    <span className="block text-[11px] sm:text-xs font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                      {item.greeting}
                    </span>
                    <span className="block text-[8px] sm:text-[9px] text-slate-400 font-medium">
                      {item.name}
                    </span>
                  </div>
                </button>
              ))}
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};

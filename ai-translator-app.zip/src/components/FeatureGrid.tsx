import React from 'react';
import { Globe, Mic, MessageSquare, Type, Sparkles, Volume2 } from 'lucide-react';

interface FeatureItem {
  icon: React.ReactNode;
  title: string;
  description: string;
  badge: string;
  glowColor: string;
  borderColor: string;
}

const FEATURES: FeatureItem[] = [
  {
    icon: <Globe className="w-6 h-6 text-cyan-400" />,
    title: '100+ Languages',
    description: 'Instant contextual translation covering global languages, regional scripts, and dialects.',
    badge: 'Global Mesh',
    glowColor: 'from-cyan-500/10 to-blue-500/5',
    borderColor: 'border-cyan-500/20 hover:border-cyan-500/50',
  },
  {
    icon: <Mic className="w-6 h-6 text-indigo-400" />,
    title: 'Voice Translation',
    description: 'Real-time neural speech recognition with ultra-low latency voice synthesis.',
    badge: '<200ms Audio',
    glowColor: 'from-indigo-500/10 to-purple-500/5',
    borderColor: 'border-indigo-500/20 hover:border-indigo-500/50',
  },
  {
    icon: <MessageSquare className="w-6 h-6 text-purple-400" />,
    title: 'Live Conversation',
    description: 'Hands-free dual avatar conversation mode for natural cross-cultural dialogue.',
    badge: 'Bilingual Mode',
    glowColor: 'from-purple-500/10 to-pink-500/5',
    borderColor: 'border-purple-500/20 hover:border-purple-500/50',
  },
  {
    icon: <Type className="w-6 h-6 text-emerald-400" />,
    title: 'Smart Text Translation',
    description: 'Translate typed text instantly while preserving context and tone.',
    badge: 'Context Engine',
    glowColor: 'from-emerald-500/10 to-teal-500/5',
    borderColor: 'border-emerald-500/20 hover:border-emerald-500/50',
  },
  {
    icon: <Sparkles className="w-6 h-6 text-amber-400" />,
    title: 'AI Context',
    description: 'Deep semantic comprehension preserving cultural idioms, honorifics, and tone.',
    badge: 'Cultural Engine',
    glowColor: 'from-amber-500/10 to-orange-500/5',
    borderColor: 'border-amber-500/20 hover:border-amber-500/50',
  },
  {
    icon: <Volume2 className="w-6 h-6 text-rose-400" />,
    title: 'Natural Voice',
    description: 'High-fidelity audio playback tuned to human vocal resonance and native phrasing cadence.',
    badge: 'Neural Audio',
    glowColor: 'from-rose-500/10 to-red-500/5',
    borderColor: 'border-rose-500/20 hover:border-rose-500/50',
  },
];

export const FeatureGrid: React.FC = () => {
  return (
    <section id="features" className="w-full py-4 sm:py-8 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-purple-500/30 text-purple-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Core Capabilities</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            Designed for the Future of Human Communication
          </h2>

          <p className="text-slate-400 text-sm sm:text-base">
            Every feature is engineered with cutting-edge Gemini AI models for unmatched speed and contextual precision.
          </p>
        </div>

        {/* 6 Glassmorphism Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((item, idx) => (
            <div
              key={idx}
              className={`group relative rounded-3xl p-6 bg-slate-900/60 border ${item.borderColor} backdrop-blur-xl shadow-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl overflow-hidden`}
            >
              {/* Card Ambient Glow */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${item.glowColor} opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none`}
              />

              <div className="relative z-10 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 group-hover:scale-110 transition-transform duration-300">
                    {item.icon}
                  </div>
                  <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-slate-950/80 text-slate-300 border border-slate-800 uppercase tracking-wider">
                    {item.badge}
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed mt-1.5">
                    {item.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

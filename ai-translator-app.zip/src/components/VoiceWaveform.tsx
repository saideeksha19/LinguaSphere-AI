import React, { useEffect, useRef } from 'react';

interface VoiceWaveformProps {
  isActive?: boolean;
  color?: string; // e.g. '#38bdf8' or '#818cf8'
}

export const VoiceWaveform: React.FC<VoiceWaveformProps> = ({
  isActive = false,
  color = '#818cf8',
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let phase = 0;

    const render = () => {
      animId = requestAnimationFrame(render);

      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const numBars = 24;
      const barWidth = width / numBars - 2;

      phase += isActive ? 0.15 : 0.03;

      for (let i = 0; i < numBars; i++) {
        // Calculate dynamic height for bars
        let barHeight: number;
        if (isActive) {
          barHeight = Math.sin(phase + i * 0.4) * (height * 0.35) + height * 0.45;
        } else {
          barHeight = Math.sin(phase + i * 0.2) * (height * 0.08) + height * 0.15;
        }

        const x = i * (barWidth + 2);
        const y = (height - barHeight) / 2;

        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = isActive ? 8 : 2;

        // Rounded rect bar
        ctx.beginPath();
        if (ctx.roundRect) {
          ctx.roundRect(x, y, barWidth, barHeight, 3);
        } else {
          ctx.rect(x, y, barWidth, barHeight);
        }
        ctx.fill();
      }
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [isActive, color]);

  return (
    <canvas
      ref={canvasRef}
      width={160}
      height={32}
      className="w-32 h-8 pointer-events-none"
    />
  );
};

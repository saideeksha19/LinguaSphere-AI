import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface City {
  name: string;
  lat: number;
  lng: number;
}

const CITIES: City[] = [
  { name: 'New York', lat: 40.7128, lng: -74.006 },
  { name: 'London', lat: 51.5074, lng: -0.1278 },
  { name: 'Paris', lat: 48.8566, lng: 2.3522 },
  { name: 'Tokyo', lat: 35.6762, lng: 139.6503 },
  { name: 'Bengaluru', lat: 12.9716, lng: 77.5946 },
  { name: 'Delhi', lat: 28.6139, lng: 77.209 },
  { name: 'San Francisco', lat: 37.7749, lng: -122.4194 },
  { name: 'Nairobi', lat: -1.2921, lng: 36.8219 },
  { name: 'Sydney', lat: -33.8688, lng: 151.2093 },
  { name: 'Rio de Janeiro', lat: -22.9068, lng: -43.1729 },
];

// Utility to convert Lat/Lng to 3D Sphere Position
function latLngToVector3(lat: number, lng: number, radius: number): THREE.Vector3 {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);

  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);

  return new THREE.Vector3(x, y, z);
}

// Generate 3D curved arc path between two points on sphere
function createArc(p1: THREE.Vector3, p2: THREE.Vector3, radius: number): THREE.CatmullRomCurve3 {
  const distance = p1.distanceTo(p2);
  const mid = p1.clone().add(p2).multiplyScalar(0.5);
  const midLength = mid.length();
  mid.normalize();
  mid.multiplyScalar(radius + distance * 0.35); // Raise arc higher based on distance

  return new THREE.CatmullRomCurve3([p1, mid, p2]);
}

export const Globe3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef<boolean>(false);
  const previousMousePosition = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth || 500;
    const height = containerRef.current.clientHeight || 500;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 240;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Clear container to prevent duplicate canvas elements
    if (containerRef.current) {
      while (containerRef.current.firstChild) {
        containerRef.current.removeChild(containerRef.current.firstChild);
      }
      containerRef.current.appendChild(renderer.domElement);
    }

    // 2. Main Globe Group
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    const radius = 80;

    // 2a. Inner Sphere (Dark translucent core)
    const sphereGeo = new THREE.SphereGeometry(radius - 0.5, 64, 64);
    const sphereMat = new THREE.MeshBasicMaterial({
      color: 0x090d1f,
      transparent: true,
      opacity: 0.92,
    });
    const sphereMesh = new THREE.Mesh(sphereGeo, sphereMat);
    globeGroup.add(sphereMesh);

    // 2b. Wireframe Latitude/Longitude lines
    const wireframeGeo = new THREE.SphereGeometry(radius, 32, 24);
    const wireframeMat = new THREE.MeshBasicMaterial({
      color: 0x4f46e5,
      wireframe: true,
      transparent: true,
      opacity: 0.15,
    });
    const wireframeMesh = new THREE.Mesh(wireframeGeo, wireframeMat);
    globeGroup.add(wireframeMesh);

    // 2c. Outer Atmosphere Glow
    const atmosGeo = new THREE.SphereGeometry(radius + 6, 32, 32);
    const atmosMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.12,
      side: THREE.BackSide,
    });
    const atmosMesh = new THREE.Mesh(atmosGeo, atmosMat);
    globeGroup.add(atmosMesh);

    // 2d. Point Cloud Dot Matrix for Globe Surface
    const particleCount = 2400;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = radius + (Math.random() - 0.5) * 1.5;

      particlePositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      particlePositions[i * 3 + 2] = r * Math.cos(phi);
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x818cf8,
      size: 1.2,
      transparent: true,
      opacity: 0.65,
    });
    const particleSystem = new THREE.Points(particleGeo, particleMat);
    globeGroup.add(particleSystem);

    // 2e. City Nodes & Glowing Markers
    const cityNodes: THREE.Vector3[] = [];
    CITIES.forEach((city) => {
      const pos = latLngToVector3(city.lat, city.lng, radius);
      cityNodes.push(pos);

      // Marker Dot
      const markerGeo = new THREE.SphereGeometry(1.8, 16, 16);
      const markerMat = new THREE.MeshBasicMaterial({ color: 0x22d3ee });
      const markerMesh = new THREE.Mesh(markerGeo, markerMat);
      markerMesh.position.copy(pos);
      globeGroup.add(markerMesh);

      // Pulse Ring
      const ringGeo = new THREE.RingGeometry(2.5, 3.8, 16);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0xa855f7,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.7,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.position.copy(pos);
      ringMesh.lookAt(pos.clone().multiplyScalar(2));
      globeGroup.add(ringMesh);
    });

    // 2f. Animated Connecting Arcs and Traveling Pulses
    const arcPulses: { curve: THREE.CatmullRomCurve3; mesh: THREE.Mesh; progress: number; speed: number }[] = [];

    // Connect pairs of cities with arcs
    const pairs = [
      [0, 1], // NY - London
      [1, 2], // London - Paris
      [1, 3], // London - Tokyo
      [3, 4], // Tokyo - Bengaluru
      [4, 5], // Bengaluru - Delhi
      [0, 6], // NY - SF
      [1, 7], // London - Nairobi
      [3, 8], // Tokyo - Sydney
      [0, 9], // NY - Rio
    ];

    pairs.forEach(([i, j]) => {
      if (!cityNodes[i] || !cityNodes[j]) return;
      const curve = createArc(cityNodes[i], cityNodes[j], radius);

      // Arc Line
      const points = curve.getPoints(50);
      const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
      const lineMat = new THREE.LineBasicMaterial({
        color: 0x6366f1,
        transparent: true,
        opacity: 0.45,
      });
      const arcLine = new THREE.Line(lineGeo, lineMat);
      globeGroup.add(arcLine);

      // Traveling Pulse Sphere on Arc
      const pulseGeo = new THREE.SphereGeometry(1.4, 12, 12);
      const pulseMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
      globeGroup.add(pulseMesh);

      arcPulses.push({
        curve,
        mesh: pulseMesh,
        progress: Math.random(),
        speed: 0.003 + Math.random() * 0.004,
      });
    });

    // Tilt Globe slightly for dynamic angle
    globeGroup.rotation.x = 0.35;
    globeGroup.rotation.y = -0.5;

    // Mouse Interaction Handlers for Drag-Rotating Globe
    const dom = renderer.domElement;

    const onMouseDown = (e: MouseEvent) => {
      isDragging.current = true;
      previousMousePosition.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging.current) return;
      const deltaX = e.clientX - previousMousePosition.current.x;
      const deltaY = e.clientY - previousMousePosition.current.y;

      globeGroup.rotation.y += deltaX * 0.005;
      globeGroup.rotation.x += deltaY * 0.005;

      previousMousePosition.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDragging.current = false;
    };

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging.current = true;
        previousMousePosition.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging.current || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - previousMousePosition.current.x;
      const deltaY = e.touches[0].clientY - previousMousePosition.current.y;

      globeGroup.rotation.y += deltaX * 0.005;
      globeGroup.rotation.x += deltaY * 0.005;

      previousMousePosition.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('touchstart', onTouchStart);
    window.addEventListener('touchmove', onTouchMove);
    window.addEventListener('touchend', onMouseUp);

    // Animation Loop
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Slow auto rotation when user is not dragging
      if (!isDragging.current) {
        globeGroup.rotation.y += 0.0025;
      }

      // Update traveling arc pulse positions
      arcPulses.forEach((pulse) => {
        pulse.progress += pulse.speed;
        if (pulse.progress > 1) pulse.progress = 0;
        const pt = pulse.curve.getPoint(pulse.progress);
        pulse.mesh.position.copy(pt);
      });

      renderer.render(scene, camera);
    };

    animate();

    // Handle Resize
    const handleResize = () => {
      if (!containerRef.current) return;
      const newW = containerRef.current.clientWidth;
      const newH = containerRef.current.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(containerRef.current);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onMouseUp);

      if (containerRef.current && dom && dom.parentNode === containerRef.current) {
        containerRef.current.removeChild(dom);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div className="relative w-full max-w-full overflow-hidden h-[360px] sm:h-[460px] lg:h-[500px] flex items-center justify-center">
      <div
        ref={containerRef}
        className="w-full h-full cursor-grab active:cursor-grabbing flex items-center justify-center select-none"
      />
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[11px] text-slate-500 font-medium px-3 py-1 rounded-full bg-slate-900/80 border border-slate-800 backdrop-blur-md pointer-events-none whitespace-nowrap max-w-[90vw] truncate text-center">
        Drag globe to rotate • Real-time AI global neural mesh
      </div>
    </div>
  );
};

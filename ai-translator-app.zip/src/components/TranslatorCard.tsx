import React, { useState, useEffect } from 'react';
import {
  ArrowLeftRight,
  Copy,
  Check,
  Trash2,
  Volume2,
  Sparkles,
  RefreshCw,
  Info,
  SlidersHorizontal,
  ArrowRight,
  Globe
} from 'lucide-react';
import { SOURCE_LANGUAGES, TARGET_LANGUAGES, POPULAR_LANGUAGES, SAMPLE_TEXTS } from '../data/languages';
import { FormalityStyle, HistoryItem, TranslationResponse } from '../types';
import { LanguageSelector } from './LanguageSelector';

interface TranslatorCardProps {
  onAddHistory: (item: HistoryItem) => void;
}

export const TranslatorCard: React.FC<TranslatorCardProps> = ({ onAddHistory }) => {
  const [sourceLang, setSourceLang] = useState<string>('auto');
  const [targetLang, setTargetLang] = useState<string>('es');
  const [inputText, setInputText] = useState<string>('');
  const [translatedText, setTranslatedText] = useState<string>('');
  const [detectedLanguage, setDetectedLanguage] = useState<string>('');
  const [pronunciation, setPronunciation] = useState<string>('');
  const [contextNote, setContextNote] = useState<string>('');
  const [formality, setFormality] = useState<FormalityStyle>('default');

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isSpeakingSource, setIsSpeakingSource] = useState<boolean>(false);
  const [isSpeakingTarget, setIsSpeakingTarget] = useState<boolean>(false);

  // Auto-translate on button click
  const handleTranslate = async () => {
    if (!inputText.trim()) {
      setErrorMsg('Please enter text to translate.');
      return;
    }

    setIsLoading(true);
    setErrorMsg('');
    setTranslatedText('');
    setPronunciation('');
    setContextNote('');

    const targetLangObj = TARGET_LANGUAGES.find((l) => l.code === targetLang);

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: inputText,
          sourceLang: sourceLang === 'auto' ? 'auto' : SOURCE_LANGUAGES.find((l) => l.code === sourceLang)?.name,
          targetLang: targetLangObj?.name || 'Spanish',
          formality,
        }),
      });

      const data: TranslationResponse = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Failed to complete translation.');
      }

      setTranslatedText(data.translatedText);
      setDetectedLanguage(data.detectedLanguage || '');
      setPronunciation(data.pronunciation || '');
      setContextNote(data.contextNote || '');

      // Add to history
      onAddHistory({
        id: Date.now().toString(),
        sourceText: inputText,
        translatedText: data.translatedText,
        sourceLang: sourceLang === 'auto' ? (data.detectedLanguage || 'Auto') : (SOURCE_LANGUAGES.find((l) => l.code === sourceLang)?.name || sourceLang),
        targetLang: targetLangObj?.name || targetLang,
        detectedLanguage: data.detectedLanguage,
        pronunciation: data.pronunciation,
        contextNote: data.contextNote,
        timestamp: Date.now(),
      });
    } catch (err: any) {
      console.error('Translation error:', err);
      setErrorMsg(err.message || 'Error communicating with translation server.');
    } finally {
      setIsLoading(false);
    }
  };

  // Swap languages
  const handleSwapLanguages = () => {
    if (sourceLang === 'auto') {
      // If source is auto-detect, set source to current target and default new target to English
      const newSource = targetLang;
      const newTarget = newSource === 'en' ? 'es' : 'en';
      setSourceLang(newSource);
      setTargetLang(newTarget);
    } else {
      const temp = sourceLang;
      setSourceLang(targetLang);
      setTargetLang(temp);
    }

    // Swap text if translation exists
    if (translatedText) {
      setInputText(translatedText);
      setTranslatedText(inputText);
      setPronunciation('');
      setContextNote('');
    }
  };

  // Clear / Reset
  const handleClear = () => {
    setInputText('');
    setTranslatedText('');
    setDetectedLanguage('');
    setPronunciation('');
    setContextNote('');
    setErrorMsg('');
  };

  // Copy output
  const handleCopy = () => {
    if (!translatedText) return;
    navigator.clipboard.writeText(translatedText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Speech synthesis
  const handleSpeak = (text: string, langCode: string, isSource: boolean) => {
    if (!text || typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    setIsSpeakingSource(false);
    setIsSpeakingTarget(false);

    window.speechSynthesis.cancel();

    if (isSource) setIsSpeakingSource(true);
    else setIsSpeakingTarget(true);

    let langObj = (isSource ? SOURCE_LANGUAGES : TARGET_LANGUAGES).find((l) => l.code === langCode);
    if (isSource && langCode === 'auto' && detectedLanguage) {
      const match = SOURCE_LANGUAGES.find(
        (l) => l.name.toLowerCase() === detectedLanguage.toLowerCase() || l.code === detectedLanguage.toLowerCase()
      );
      if (match) langObj = match;
    }

    const speechLang = langObj?.speechCode || 'en-US';

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = speechLang;
    utterance.rate = 0.95;

    const playSpeech = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices && voices.length > 0) {
        const langPrefix = speechLang.split('-')[0];
        const match =
          voices.find((v) => v.lang === speechLang) ||
          voices.find((v) => v.lang.startsWith(langPrefix));
        if (match) {
          utterance.voice = match;
        }
      }

      utterance.onend = () => {
        setIsSpeakingSource(false);
        setIsSpeakingTarget(false);
      };

      utterance.onerror = (e: SpeechSynthesisErrorEvent) => {
        if (e.error === 'interrupted' || e.error === 'canceled') {
          setIsSpeakingSource(false);
          setIsSpeakingTarget(false);
          return;
        }
        console.warn('Speech synthesis warning:', e.error || e);
        setIsSpeakingSource(false);
        setIsSpeakingTarget(false);
      };

      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      window.speechSynthesis.speak(utterance);
    };

    setTimeout(playSpeech, 50);
  };

  const wordCount = inputText.trim() ? inputText.trim().split(/\s+/).length : 0;

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800/90 rounded-3xl p-4 sm:p-6 shadow-2xl shadow-slate-950/50 backdrop-blur-xl">
      {/* Top Header Controls: Language Selectors & Swap */}
      <div className="grid grid-cols-1 md:grid-cols-21 gap-3 items-center mb-5">
        {/* Source Language Selector */}
        <div className="flex-1">
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
            <span>From Language</span>
            {detectedLanguage && sourceLang === 'auto' && (
              <span className="text-[11px] text-indigo-400 font-normal">
                Detected: <strong className="font-semibold">{detectedLanguage}</strong>
              </span>
            )}
          </label>
          <LanguageSelector
            id="source-lang-selector"
            languages={SOURCE_LANGUAGES}
            selectedLanguage={sourceLang}
            onSelectLanguage={setSourceLang}
            popularCodes={POPULAR_LANGUAGES}
            isSource={true}
          />
        </div>

        {/* Swap Button */}
        <div className="flex justify-center md:pt-5">
          <button
            type="button"
            onClick={handleSwapLanguages}
            title="Swap Source and Target Languages"
            className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-indigo-600/20 text-slate-300 hover:text-indigo-400 border border-slate-700/80 hover:border-indigo-500/40 transition-all duration-200 active:scale-95 group"
          >
            <ArrowLeftRight className="w-4 h-4 group-hover:rotate-180 transition-transform duration-300" />
          </button>
        </div>

        {/* Target Language Selector */}
        <div className="flex-1">
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
            To Language
          </label>
          <LanguageSelector
            id="target-lang-selector"
            languages={TARGET_LANGUAGES}
            selectedLanguage={targetLang}
            onSelectLanguage={setTargetLang}
            popularCodes={POPULAR_LANGUAGES}
            isSource={false}
          />
        </div>
      </div>

      {/* Tone / Formality Selector bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-800/70">
        <div className="flex items-center space-x-2">
          <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-medium text-slate-400">Tone & Formality:</span>
          <div className="inline-flex p-0.5 rounded-lg bg-slate-950 border border-slate-800">
            {(['default', 'formal', 'casual'] as FormalityStyle[]).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFormality(f)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium capitalize transition-all ${
                  formality === f
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {f === 'default' ? 'Natural / Auto' : f}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Sample Prompts */}
        <div className="hidden sm:flex items-center space-x-1.5 overflow-x-auto">
          <span className="text-[11px] text-slate-500 font-medium">Quick text:</span>
          {SAMPLE_TEXTS.map((sample, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setInputText(sample.text)}
              className="px-2 py-0.5 rounded bg-slate-800/50 hover:bg-slate-800 text-[11px] text-slate-400 hover:text-slate-200 transition-colors whitespace-nowrap"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Text Input and Output Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Source Input Area */}
        <div className="flex flex-col rounded-2xl bg-slate-950/80 border border-slate-800 p-4 transition-all focus-within:border-indigo-500/50 focus-within:ring-1 focus-within:ring-indigo-500/20 min-h-[220px]">
          <div className="flex items-center justify-between pb-2 border-b border-slate-900">
            <span className="text-xs font-medium text-slate-400">Source Text</span>
            {inputText && (
              <button
                type="button"
                onClick={handleClear}
                className="text-slate-500 hover:text-rose-400 text-xs flex items-center space-x-1 transition-colors"
                title="Clear input"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
          </div>

          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Enter or paste text to translate..."
            className="w-full flex-1 mt-3 bg-transparent text-slate-100 placeholder-slate-600 text-base resize-none focus:outline-none min-h-[140px] leading-relaxed"
          />

          <div className="flex items-center justify-between pt-3 mt-auto border-t border-slate-900 text-xs text-slate-500">
            <div className="flex items-center space-x-3">
              <span>{inputText.length} chars</span>
              <span>•</span>
              <span>{wordCount} words</span>
            </div>
            {inputText && (
              <button
                type="button"
                onClick={() => handleSpeak(inputText, sourceLang, true)}
                title="Listen to source text"
                className={`p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-indigo-400 transition-colors ${
                  isSpeakingSource ? 'text-indigo-400 animate-pulse' : ''
                }`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* AI Output Area */}
        <div className="flex flex-col rounded-2xl bg-slate-950/80 border border-slate-800 p-4 relative min-h-[220px]">
          <div className="flex items-center justify-between pb-2 border-b border-slate-900">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-medium text-slate-400">Translation Output</span>
              <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Context Preserved
              </span>
            </div>

            {translatedText && (
              <button
                type="button"
                onClick={handleCopy}
                className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  isCopied
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
                }`}
              >
                {isCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            )}
          </div>

          <div className="flex-1 mt-3 relative min-h-[140px]">
            {isLoading ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center space-y-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full border-2 border-indigo-500/20 border-t-indigo-500 animate-spin" />
                  <Sparkles className="w-4 h-4 text-indigo-400 absolute inset-0 m-auto animate-pulse" />
                </div>
                <p className="text-xs text-indigo-300 font-medium animate-pulse">
                  Gemini AI processing context & nuances...
                </p>
              </div>
            ) : translatedText ? (
              <div className="space-y-3">
                <p className="text-slate-100 text-base leading-relaxed whitespace-pre-wrap select-text font-sans">
                  {translatedText}
                </p>

                {/* Phonetic / Pronunciation if available */}
                {pronunciation && (
                  <div className="pt-2 border-t border-slate-900/80">
                    <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-0.5">
                      Pronunciation
                    </span>
                    <p className="text-xs text-indigo-300/90 italic font-mono bg-indigo-950/30 px-2.5 py-1.5 rounded-lg border border-indigo-900/30">
                      {pronunciation}
                    </p>
                  </div>
                )}

                {/* Cultural / Context Note if available */}
                {contextNote && (
                  <div className="pt-2">
                    <div className="flex items-start space-x-2 bg-slate-900/70 p-2.5 rounded-xl border border-slate-800 text-xs text-slate-300">
                      <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-amber-300 block mb-0.5">Context & Nuance Note</span>
                        <p className="text-slate-400 text-[11px] leading-relaxed">{contextNote}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-600">
                <Globe className="w-8 h-8 mb-2 stroke-[1.5] text-slate-700" />
                <p className="text-xs text-slate-500 max-w-xs">
                  Select languages and enter text above to generate a context-aware AI translation.
                </p>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-3 mt-auto border-t border-slate-900 text-xs text-slate-500">
            <span>AI Output</span>
            {translatedText && (
              <button
                type="button"
                onClick={() => handleSpeak(translatedText, targetLang, false)}
                title="Listen to translation"
                className={`p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-indigo-400 transition-colors ${
                  isSpeakingTarget ? 'text-indigo-400 animate-pulse' : ''
                }`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Error display */}
      {errorMsg && (
        <div className="mt-4 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-lg">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-rose-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <div className="flex items-center space-x-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={handleTranslate}
              disabled={isLoading || !inputText.trim()}
              className="px-3 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/30 text-xs font-semibold transition-colors flex items-center space-x-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry Now</span>
            </button>
            <button
              type="button"
              onClick={() => setErrorMsg('')}
              className="text-rose-400 hover:text-rose-200 font-bold px-1 text-sm"
              title="Dismiss"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Main Action Bar */}
      <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800/80">
        <button
          type="button"
          onClick={handleClear}
          disabled={!inputText && !translatedText}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center space-x-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Input & Output</span>
        </button>

        <button
          type="button"
          onClick={handleTranslate}
          disabled={isLoading || !inputText.trim()}
          className="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-sm font-semibold shadow-lg shadow-indigo-600/25 transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Translating...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Translate with Gemini AI</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { Search, ChevronDown, Check } from 'lucide-react';
import { Language } from '../types';

interface LanguageSelectorProps {
  id: string;
  languages: Language[];
  selectedLanguage: string; // code
  onSelectLanguage: (code: string) => void;
  popularCodes?: string[];
  isSource?: boolean;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  id,
  languages,
  selectedLanguage,
  onSelectLanguage,
  popularCodes = [],
  isSource = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedLangObj = languages.find((l) => l.code === selectedLanguage) || languages[0];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredLanguages = languages.filter((lang) => {
    const query = searchQuery.toLowerCase().trim();
    if (!query) return true;
    return (
      lang.name.toLowerCase().includes(query) ||
      (lang.nativeName && lang.nativeName.toLowerCase().includes(query)) ||
      lang.code.toLowerCase().includes(query)
    );
  });

  const popularLanguages = languages.filter((lang) => popularCodes.includes(lang.code));

  return (
    <div className="relative" ref={dropdownRef} id={id}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 text-slate-100 font-medium text-sm transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
      >
        <div className="flex items-center space-x-2.5 truncate">
          <span className="text-base leading-none">{selectedLangObj.flag || '🌐'}</span>
          <span className="truncate">{selectedLangObj.name}</span>
          {selectedLangObj.nativeName && selectedLangObj.code !== 'auto' && (
            <span className="text-xs text-slate-400 font-normal hidden sm:inline">
              ({selectedLangObj.nativeName})
            </span>
          )}
        </div>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${isOpen ? 'rotate-180 text-indigo-400' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute left-0 right-0 top-full mt-2 z-50 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl shadow-black/80 overflow-hidden flex flex-col max-h-80 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="p-2.5 border-b border-slate-800/80 bg-slate-950/50">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search languages..."
                autoFocus
                className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500/50"
              />
            </div>
          </div>

          {popularLanguages.length > 0 && !searchQuery && (
            <div className="p-2.5 border-b border-slate-800/60 bg-slate-950/30">
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Popular
              </div>
              <div className="flex flex-wrap gap-1.5">
                {isSource && (
                  <button
                    type="button"
                    onClick={() => {
                      onSelectLanguage('auto');
                      setIsOpen(false);
                    }}
                    className={`px-2 py-1 rounded-md text-xs transition-colors ${
                      selectedLanguage === 'auto'
                        ? 'bg-indigo-600 text-white font-medium'
                        : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    Auto Detect
                  </button>
                )}
                {popularLanguages.map((lang) => (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => {
                      onSelectLanguage(lang.code);
                      setIsOpen(false);
                    }}
                    className={`px-2 py-1 rounded-md text-xs flex items-center space-x-1 transition-colors ${
                      selectedLanguage === lang.code
                        ? 'bg-indigo-600 text-white font-medium'
                        : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <span>{lang.flag}</span>
                    <span>{lang.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="overflow-y-auto p-1.5 space-y-0.5">
            {filteredLanguages.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-500">
                No languages found matching "{searchQuery}"
              </div>
            ) : (
              filteredLanguages.map((lang) => {
                const isSelected = selectedLanguage === lang.code;
                return (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => {
                      onSelectLanguage(lang.code);
                      setIsOpen(false);
                      setSearchQuery('');
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs transition-colors ${
                      isSelected
                        ? 'bg-indigo-600/20 text-indigo-300 font-medium'
                        : 'text-slate-300 hover:bg-slate-800/70'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 truncate">
                      <span className="text-sm">{lang.flag || '🌐'}</span>
                      <span className="truncate">{lang.name}</span>
                      {lang.nativeName && lang.code !== 'auto' && (
                        <span className="text-[11px] text-slate-500 font-normal truncate">
                          • {lang.nativeName}
                        </span>
                      )}
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0 ml-2" />}
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};

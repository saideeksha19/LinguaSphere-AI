import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini client lazily
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is not set. Please set it in Settings > Secrets.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
};

app.post("/api/translate", async (req, res) => {
  try {
    const { text, sourceLang, targetLang, formality } = req.body;

    if (!text || typeof text !== "string" || !text.trim()) {
      return res.status(400).json({ error: "Text is required for translation." });
    }

    if (!targetLang) {
      return res.status(400).json({ error: "Target language is required." });
    }

    const ai = getGeminiClient();

    const formalityInstruction = formality && formality !== 'default'
      ? `Tone requirement: Use a ${formality} style.`
      : '';

    const sourceInstruction = sourceLang && sourceLang !== 'auto'
      ? `Source Language: ${sourceLang}`
      : `Source Language: Auto-detect the language from input text.`;

    const prompt = `Translate the following text accurately into ${targetLang}.
${sourceInstruction}
Target Language: ${targetLang}
${formalityInstruction}

Text to translate:
"""
${text}
"""

Instructions:
1. Provide an idiomatic, natural translation that preserves the original meaning, intent, and cultural context. Do not perform simple word-for-word replacement.
2. If source language was auto-detected, identify it in 'detectedLanguage'.
3. If the target language uses a non-Latin script (such as Chinese, Japanese, Korean, Hindi, Arabic, Russian, Thai, Greek, Hebrew, etc.), provide a helpful romanized pronunciation / transliteration in 'pronunciation'. Otherwise, leave 'pronunciation' empty.
4. If there is an important cultural nuance, idiomatic expression, or tone detail preserved, provide a concise 1-sentence note in 'contextNote'. Otherwise leave 'contextNote' empty.`;

    const candidateModels = ["gemini-3.6-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"];
    let responseText = "";
    let lastError: any = null;
    const rateLimitedModels = new Set<string>();

    // Strategy 1: Attempt JSON schema mode with candidate models
    for (const modelName of candidateModels) {
      if (rateLimitedModels.has(modelName)) continue;

      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: prompt,
            config: {
              systemInstruction: "You are an expert AI language translator. Translate input text with high precision, preserving context, tone, and cultural nuance.",
              temperature: 0.3,
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  translatedText: {
                    type: Type.STRING,
                    description: "The translated text in the target language."
                  },
                  detectedLanguage: {
                    type: Type.STRING,
                    description: "The detected source language name if auto-detected or specified."
                  },
                  pronunciation: {
                    type: Type.STRING,
                    description: "Romanization or phonetic guide if target language is non-Latin."
                  },
                  contextNote: {
                    type: Type.STRING,
                    description: "Brief note about preserved context, idiom, or nuance if applicable."
                  }
                },
                required: ["translatedText"]
              }
            }
          });

          if (response.text) {
            responseText = response.text;
            lastError = null;
            break;
          }
        } catch (err: any) {
          lastError = err;
          const is429 = err?.message?.includes("429") || err?.message?.includes("RESOURCE_EXHAUSTED") || err?.status === 429;
          if (is429) {
            rateLimitedModels.add(modelName);
            // On 429 rate limit, skip directly to next model
            break;
          }
        }
      }
      if (responseText) break;
    }

    // Strategy 2: Fallback to lightweight plain text prompt if structured schema failed
    if (!responseText && rateLimitedModels.size < candidateModels.length) {
      const plainPrompt = `Translate the following text into ${targetLang}. Return ONLY the direct translation, nothing else.
${sourceInstruction}

Text:
"""
${text}
"""`;

      for (const modelName of candidateModels) {
        if (rateLimitedModels.has(modelName)) continue;
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: plainPrompt,
          });
          if (response.text) {
            responseText = JSON.stringify({
              translatedText: response.text.trim(),
              detectedLanguage: sourceLang !== 'auto' ? sourceLang : '',
              pronunciation: '',
              contextNote: ''
            });
            lastError = null;
            break;
          }
        } catch (err: any) {
          lastError = err;
          const is429 = err?.message?.includes("429") || err?.message?.includes("RESOURCE_EXHAUSTED") || err?.status === 429;
          if (is429) {
            rateLimitedModels.add(modelName);
          }
        }
      }
    }

    if (!responseText) {
      console.warn("Gemini API calls failed or rate limited. Using fallback translation engine.");
      const normText = text.trim().toLowerCase().replace(/[.,!?]/g, "");
      const normTarget = targetLang.toLowerCase();

      const FALLBACK_DICTIONARY: Record<string, Record<string, { translatedText: string; pronunciation: string }>> = {
        "hello": {
          "kannada": { translatedText: "ಹಲೋ", pronunciation: "Halō" },
          "telugu": { translatedText: "హాయ్", pronunciation: "Hāy" },
          "hindi": { translatedText: "नमस्ते", pronunciation: "Namaste" },
          "tamil": { translatedText: "வணக்கம்", pronunciation: "Vaṇakkam" },
          "spanish": { translatedText: "Hola", pronunciation: "Hola" },
          "japanese": { translatedText: "こんにちは", pronunciation: "Konnichiwa" },
          "english": { translatedText: "Hello", pronunciation: "Hello" },
        },
        "hi": {
          "kannada": { translatedText: "ಹಲೋ", pronunciation: "Halō" },
          "telugu": { translatedText: "హాయ్", pronunciation: "Hāy" },
          "hindi": { translatedText: "नमस्ते", pronunciation: "Namaste" },
          "tamil": { translatedText: "வணக்கம்", pronunciation: "Vaṇakkam" },
          "spanish": { translatedText: "Hola", pronunciation: "Hola" },
          "japanese": { translatedText: "こんにちは", pronunciation: "Konnichiwa" },
          "english": { translatedText: "Hi", pronunciation: "Hi" },
        },
        "thank you": {
          "kannada": { translatedText: "ಧನ್ಯವಾದಗಳು", pronunciation: "Dhanyavādagalu" },
          "telugu": { translatedText: "ధన్యవాదాలు", pronunciation: "Dhanyavādālu" },
          "hindi": { translatedText: "धन्यवाद", pronunciation: "Dhanyavād" },
          "tamil": { translatedText: "நன்றி", pronunciation: "Naṇri" },
          "spanish": { translatedText: "Gracias", pronunciation: "Gracias" },
          "japanese": { translatedText: "ありがとう", pronunciation: "Arigatō" },
          "english": { translatedText: "Thank you", pronunciation: "Thank you" },
        },
        "how are you": {
          "kannada": { translatedText: "ನೀವು ಹೇಗಿದ್ದೀರಿ?", pronunciation: "Nīvu hēgiddīri?" },
          "telugu": { translatedText: "మీరు ఎలా ఉన్నారు?", pronunciation: "Mīru elā unnāru?" },
          "hindi": { translatedText: "आप कैसे हैं?", pronunciation: "Āp kaise haiṁ?" },
          "spanish": { translatedText: "¿Cómo estás?", pronunciation: "¿Cómo estás?" },
          "japanese": { translatedText: "お元気ですか？", pronunciation: "Ogenki desu ka?" },
          "english": { translatedText: "How are you?", pronunciation: "How are you?" },
        },
        "welcome": {
          "kannada": { translatedText: "ಸ್ವಾಗತ", pronunciation: "Svāgata" },
          "telugu": { translatedText: "స్వాగతం", pronunciation: "Svāgataṁ" },
          "hindi": { translatedText: "स्वागत है", pronunciation: "Svāgat hai" },
          "spanish": { translatedText: "Bienvenido", pronunciation: "Bienvenido" },
          "japanese": { translatedText: "ようこそ", pronunciation: "Yōkoso" },
          "english": { translatedText: "Welcome", pronunciation: "Welcome" },
        },
      };

      let fallbackMatch = null;
      for (const [key, langMap] of Object.entries(FALLBACK_DICTIONARY)) {
        if (normText.includes(key)) {
          for (const [langKey, matchObj] of Object.entries(langMap)) {
            if (normTarget.includes(langKey)) {
              fallbackMatch = matchObj;
              break;
            }
          }
        }
        if (fallbackMatch) break;
      }

      const finalTranslatedText = fallbackMatch ? fallbackMatch.translatedText : text;
      const finalPronunciation = fallbackMatch ? fallbackMatch.pronunciation : "";

      return res.json({
        translatedText: finalTranslatedText,
        detectedLanguage: sourceLang !== "auto" ? sourceLang : "Auto",
        pronunciation: finalPronunciation,
        contextNote: "API rate limit reached. Fallback translation engine used.",
      });
    }

    let parsedData = { translatedText: "", detectedLanguage: "", pronunciation: "", contextNote: "" };

    try {
      parsedData = JSON.parse(responseText);
    } catch (e) {
      parsedData = {
        translatedText: responseText,
        detectedLanguage: sourceLang !== 'auto' ? sourceLang : '',
        pronunciation: '',
        contextNote: ''
      };
    }

    return res.json(parsedData);
  } catch (error: any) {
    console.error("Translation API error:", error);
    let message = error?.message || "Failed to translate text. Please check your Gemini API key.";
    if (typeof message === 'string' && (message.includes("429") || message.includes("quota") || message.includes("RESOURCE_EXHAUSTED"))) {
      message = "Gemini API rate limit or daily quota reached. Please wait a few seconds and try again.";
      return res.status(429).json({ error: message });
    }
    return res.status(500).json({
      error: message
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
